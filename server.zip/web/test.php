<!DOCTYPE html>
<html lang="en">
<head>
<title>test.php</title>
<meta charset="utf-8">
<link rel="shortcut icon" href="ok.ico">
<style>
body {margin:0px;;background-color:#bececa;color:#008;font-family:Lucida Console;font-size:20.5pt;overflow:hidden;}
</style>
<body>
<?php
echo "<br><br><br>";
echo "<center>I am a php page!!!</center>";
?>
</body>
</html> 
